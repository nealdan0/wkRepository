package com.wk.prototype.RestServices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wk.prototype.DataModel.MockDataModel;
import com.wk.prototype.ModelDAO.ItemDetailDAO;

@RestController
public class ItemDetailModelService  {

	@Autowired
	MockDataModel mockDataModel;
	
	private static final Logger logger = LoggerFactory.getLogger(ItemDetailModelService.class);

	private int nextId = 0;
	private int nextItemDetailId = 0;


	/**
	 * @return
	 */
	@RequestMapping(value = "/ItemDetail/{listId}/{timeStamp}", method = RequestMethod.GET)
	public synchronized List<ItemDetailDAO> getAllItemDetail(@PathVariable("listId") int itemId, @PathVariable("timeStamp") String timeStamp) {

		//timestamp is a dirty rotten hack used only to ensure a unique url on each execution
		System.out.println("in getAllItemDetail for id: " + itemId + " timeStamp:" + timeStamp);

		return mockDataModel.getItemDetailList(itemId);
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/ItemDetail/{listId}", method = RequestMethod.POST)
	public synchronized List<ItemDetailDAO> addItemDetail(@PathVariable("listId") int itemId,
			@RequestBody ItemDetailDAO itemDetail) {

		System.out.println("in addItemDetail for id: " + itemId + "name: " + itemDetail.getName());
		mockDataModel.addItemDetail(itemId, itemDetail);
		System.out.println("getting update item detail list for return");
		return mockDataModel.getItemDetailList(itemId);
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/ItemDetail/{listId}/{id}", method = RequestMethod.DELETE)
	public synchronized List<ItemDetailDAO> deleteItemDetail(@PathVariable("listId") int itemId,@PathVariable("id") int itemDetailId) {

		System.out.println("in deleteItemDetail for id: " + itemId + "  detail:" + itemDetailId);
		mockDataModel.removeItemDetail(itemId, itemDetailId);
		return mockDataModel.getItemDetailList(itemId);
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/ItemDetail/{listId}/{id}", method = RequestMethod.PUT)
	public synchronized List<ItemDetailDAO> updateItemDetail(@PathVariable("listId")int itemId, @PathVariable("id") int itemDetailId,
			@RequestBody ItemDetailDAO itemDetail) {

		System.out.println("in updateItemDetail for itemId: " + itemId + "itemDetailId: " + itemDetailId  + "Name:" + itemDetail.getName() + " complete:" + itemDetail.isComplete());
		mockDataModel.updateItemDetail(itemId, itemDetailId, itemDetail);
		return mockDataModel.getItemDetailList(itemId);
	}



}
