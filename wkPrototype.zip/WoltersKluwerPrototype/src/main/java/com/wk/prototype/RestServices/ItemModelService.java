package com.wk.prototype.RestServices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wk.prototype.DataModel.MockDataModel;
import com.wk.prototype.ModelDAO.ItemDAO;
import com.wk.prototype.ModelDAO.ItemDetailDAO;

@RestController
public class ItemModelService {

	private static final Logger logger = LoggerFactory.getLogger(ItemModelService.class);

	@Autowired
	MockDataModel mockDataModel;

	/**
	 * @return
	 */
	@RequestMapping(value = "/Item/{timeStamp}", method = RequestMethod.GET)
	public synchronized List<ItemDAO> getAllItems(@PathVariable("timeStamp") String timeStamp) {
		// public ToDoListDAO getAllToDoList(){

		// timeStamp is an ugly hack to force url to be slightly different each
		// execution to avoid caching issues
		System.out.println("in getAllItems timeStamp: " + timeStamp);

		return mockDataModel.getItemList();
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/Item", method = RequestMethod.POST)
	public synchronized List<ItemDAO> addItem(@RequestBody ItemDAO item) {

		System.out.println("in addItem itemName: " + item.getName());
		mockDataModel.addItem(item);
		return mockDataModel.getItemList();
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/Item/{listId}", method = RequestMethod.PUT)
	public synchronized List<ItemDAO> updateItem(@PathVariable("listId")int itemId,
			@RequestBody ItemDAO item) {

		System.out.println("in updateItem for itemId: " + itemId   + "Name:" + item.getName());
		mockDataModel.updateItem(itemId, item);
		return mockDataModel.getItemList();
	}
	/**
	 * @return
	 */
	@RequestMapping(value = "/Item/{id}", method = RequestMethod.DELETE)
	public synchronized List<ItemDAO> deleteItem(@PathVariable("id") int id) {

		System.out.println("in deleteItem");

		mockDataModel.removeItem(id);
		return mockDataModel.getItemList();
	}

}
