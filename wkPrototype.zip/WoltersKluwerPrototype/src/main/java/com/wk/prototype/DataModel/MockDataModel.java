package com.wk.prototype.DataModel;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wk.prototype.ModelDAO.ItemDetailDAO;
import com.wk.prototype.ModelDAO.ItemDAO;

public class MockDataModel {

	private static final Logger logger = LoggerFactory.getLogger(MockDataModel.class);

	private int itemId = 0;
	private int itemDetailId = 0;

	private  List<ItemDAO> itemList = new ArrayList<ItemDAO>();

	public synchronized int incrementItemId() {
		return itemId++;
	}

	public synchronized int incrementItemDetailId() {
		return itemDetailId++;
	}

	public List<ItemDAO> getItemList() {
		return itemList;
	}

	public synchronized ItemDAO getItem(int itemId) {

		Iterator<ItemDAO> it = itemList.iterator();
		while (it.hasNext()) {
			ItemDAO tdItem = (ItemDAO) it.next();
			if (tdItem.getId() == itemId) {
				return tdItem;
			}
		}
		return null;
	}

	public synchronized ItemDAO addItem(ItemDAO item) {
		item.setId(incrementItemId());
		item.setItemDetailList(new ArrayList<ItemDetailDAO>());
		getItemList().add(item);
		return item;
	}
	
	public synchronized ItemDAO updateItem(int itemId, ItemDAO item) {
		ItemDAO currItem = this.getItem(itemId);
		currItem.setName(item.getName());
		return currItem;
	}


	public synchronized void removeItem(int itemId) {
		ItemDAO item = getItem(itemId);
		itemList.remove(item);
	}

	public synchronized List<ItemDetailDAO> getItemDetailList(int itemId) {
		System.out.println("getting item detail list for item id: " + itemId);
		Iterator<ItemDAO> it = itemList.iterator();
		while (it.hasNext()) {
			ItemDAO item = it.next();
			if (item.getId() == itemId) {
				return item.getItemDetailList();
			}
		}
		return null;
	}

	public synchronized ItemDetailDAO getItemDetail(int itemId, int itemDetailId) {

		List<ItemDetailDAO> itemDetailList = getItemDetailList(itemId);
		Iterator<ItemDetailDAO> it = itemDetailList.iterator();
		while (it.hasNext()) {
			ItemDetailDAO itemDetail = it.next();
			if (itemDetail.getId() == itemDetailId) {
				return itemDetail;
			}
		}

		return null;
	}

	public synchronized ItemDetailDAO addItemDetail(int itemId, ItemDetailDAO itemDetail) {
		System.out.println("getting time for itemId: " + itemId + " itemDetailName: " + itemDetail.getName());
		ItemDAO item = getItem(itemId);
		if (item != null) {
			itemDetail.setId(incrementItemDetailId());
			item.getItemDetailList().add(itemDetail);
		}
		return itemDetail;
	}

	public synchronized ItemDetailDAO updateItemDetail(int itemId, int itemDetailId, ItemDetailDAO itemDetail) {

		ItemDetailDAO currentItemDetail = getItemDetail(itemId, itemDetailId);
		currentItemDetail.setComplete(itemDetail.isComplete());
		currentItemDetail.setName(itemDetail.getName());
		return currentItemDetail;
	}

	public synchronized void removeItemDetail(int itemId, int itemDetailId) {
		ItemDetailDAO itemDetail = getItemDetail(itemId, itemDetailId);
		getItemDetailList(itemId).remove(itemDetail);
	}

}
