package com.wk.prototype.ModelDAO;

import java.util.List;

public class ItemDAO {
private String name;
private int id;
private List<ItemDetailDAO> itemDetailList;


public List<ItemDetailDAO> getItemDetailList() {
	return itemDetailList;
}
public void setItemDetailList(List<ItemDetailDAO> itemDetailList) {
	this.itemDetailList = itemDetailList;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
