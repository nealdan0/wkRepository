	
$scope.addToDoList1 = function($scope){
		
		$scope.traceMessage = "called add to do list script function";
		
		response = prompt("Please Enter the new list name", "");
		
		$scope.testMessage = response;
	};

