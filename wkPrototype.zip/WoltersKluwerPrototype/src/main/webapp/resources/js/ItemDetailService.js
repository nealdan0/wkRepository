wkAppDetailApp.service('ItemDetailService', function($http, $q) {

	this.addItemDetail = function(listId) {
		var deferred = $q.defer();
		itemDetailName = prompt("Please enter item detail name", "");

		if (itemDetailName == null) {
		} else if (itemDetailName == "") {
		} else {
			$http.post('/wkPrototype/services/ItemDetail/' + listId, {name : itemDetailName})
			.success(function(data, status, headers, config) {
				deferred.resolve(data);
			})
			.error(function(data, status, headers, config) {
				deferred.reject("error in addItem");
			});
		};
		return deferred.promise;
	};

	this.deleteItemDetail = function(listId, id) {
		var deferred = $q.defer();
		$http.delete('/wkPrototype/services/ItemDetail/' + listId + "/" + id)
		.success(function(data, status, headers, config) {
			deferred.resolve(data);
		})
		.error(function(data, status, headers, config) {
			deferred.reject("error in deleteItem");
		});

		return deferred.promise;
	};
	
	
	this.updateItemDetail = function(listId, id, complete, itemName) {
		
		var deferred = $q.defer();
		$http.put('/wkPrototype/services/ItemDetail/' + listId + '/' + id, {name : itemName, complete:complete})
		.success(function(data, status, headers, config) {
			deferred.resolve(data);
		})
		.error(function(data, status, headers, config) {
			deferred.reject("error in updateItem");
		});

		return deferred.promise;
	};

	this.listItemDetail = function(listId) {
		var deferred = $q.defer();
		var timeStamp = Date.now();

		$http.get('/wkPrototype/services/ItemDetail/' + listId + "/"+ timeStamp)
		.success(function(data, status, headers, config) {
			deferred.resolve(data);
		})
		.error(function(data, status, headers, config) {
			deferred.reject("error in listItems");
		});

		return deferred.promise;
	};

});
