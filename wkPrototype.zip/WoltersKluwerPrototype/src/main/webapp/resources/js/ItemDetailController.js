var wkAppDetailApp = angular.module('wkDetailApp', [ 'ngRoute' ]);

wkAppDetailApp.controller('wkToDoListDetailController', function($scope,
		$location, $q, ItemDetailService) {

	var urlParams = $location.search();

	$scope.listId = urlParams.id;
	$scope.itemName = urlParams.name;
	var listId = urlParams.id;

	$scope.addItemDetail = function(listId) {
		var addPromise = ItemDetailService.addItemDetail(listId);
		addPromise.then(function(data) {
			$scope.itemDetailList = data;
			$scope.$apply();
		})
	};
	
	$scope.updateItemDetail = function(listId,id,complete,itemName) {
		newItemName = prompt("enter new item name",itemName);
		var addPromise = ItemDetailService.updateItemDetail(listId,id, complete, newItemName);
		addPromise.then(function(data) {
			$scope.itemDetailList = data;
			$scope.$apply();
		})
	};
	
	$scope.toggleItemDetail = function(listId,id,complete,itemName) {
		if (complete == true){
			complete = false;
		}
		else{
			complete = true;
		}
						
		var addPromise = ItemDetailService.updateItemDetail(listId,id, complete, itemName);
		addPromise.then(function(data) {
			$scope.itemDetailList = data;
			$scope.$apply();
		})
	};
	
	$scope.deleteItemDetail = function(listId, id) {
		var addPromise = ItemDetailService.deleteItemDetail(listId, id);
		addPromise.then(function(data) {
			$scope.itemDetailList = data;
			$scope.$apply();
		})
	};


	var initPage = function() {
		var listPromise = ItemDetailService.listItemDetail(listId);
		listPromise.then(function(data) {
			$scope.itemDetailList = data;
			$scope.$apply();
		});
	};
	initPage();
})