var wkApp = angular.module('wkApp', []);
wkApp.controller('wkController', function($scope, $http, $q, $location,
		ItemService) {

	$scope.addItem = function() {
		alert("in add item");
		var addPromise = ItemService.addItem();
		addPromise.then(function(data) {
			$scope.toDoList = data;
			$scope.$apply();
		})
	};

	$scope.deleteItem = function(id, name) {
		var deletePromise = ItemService.deleteItem(id, name);
		deletePromise.then(function(data) {
			$scope.toDoList = data;
			$scope.$apply();
		})
	};
	
	$scope.updateItem = function(id, name) {
		var updatePromise = ItemService.updateItem(id, name);
		updatePromise.then(function(data) {
			$scope.toDoList = data;
			$scope.$apply();
		})
	};
	
	var initPage = function(){
		var listPromise = ItemService.listItems();
		listPromise.then(function(data) {
			$scope.toDoList = data;
			$scope.$apply();
		});
	};
	
	initPage();
});