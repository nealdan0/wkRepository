wkApp.service('ItemService', function($http,$q) {

	this.addItem = function() {
		var deferred = $q.defer();
		itemName = prompt("Please enter item name", "");

		if (itemName == null) {
		} else if (itemName == "") {
		} else {
			$http.post('/wkPrototype/services/Item',{name:itemName})
			.success(function(data, status, headers, config) {
				deferred.resolve(data);
			})
			.error(function(data, status, headers, config) {
				deferred.reject("error in addItem");
			});
		}

		return deferred.promise;
	};
	
	this.updateItem = function(id, name) {
		var deferred = $q.defer();
		itemName = prompt("Please enter item name", name);

		if (itemName == null) {
		} else if (itemName == "") {
		} else {
			$http.put('/wkPrototype/services/Item/' + id,{name:itemName})
			.success(function(data, status, headers, config) {
				deferred.resolve(data);
			})
			.error(function(data, status, headers, config) {
				deferred.reject("error in updateItem");
			});
		};

		return deferred.promise;
	};

	
	
	this.deleteItem = function(id, name) {
		var deferred = $q.defer();
		$http.delete('/wkPrototype/services/Item/' + id)
		.success(function(data, status, headers, config) {
			deferred.resolve(data);
		})
		.error(function(data, status, headers, config) {
			deferred.reject("error in deleteItem");
		});
		
		return deferred.promise;
	};

	
	
	this.listItems = function() {
		var deferred = $q.defer();

		 var timeStamp = Date.now();
		 
			$http.get("/wkPrototype/services/Item/" + timeStamp)
			.success(function(data, status, headers, config) {
				deferred.resolve(data);
			})
			.error(function(data, status, headers, config) {
				deferred.reject("error in listItems");
			});
			
			return deferred.promise;		
	};
	
});
