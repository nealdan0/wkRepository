package com.wk.prototype.RestServices;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.wk.prototype.DataModel.MockDataModel;
import com.wk.prototype.ModelDAO.ItemDAO;
import com.wk.prototype.ModelDAO.ItemDetailDAO;

public class ItemDetailModelServiceTest {

	private MockDataModel mockDataModel;
	private int numberOfDetails = 5;

	/*
	 * 
	 */
	@Before
	public void init() {
		mockDataModel = new MockDataModel();
		numberOfDetails = 5;
		for (int i = 0; i < 10; i++) {
			ItemDAO item = new ItemDAO();
			item.setId(i);
			item.setName("item " + i);
			mockDataModel.addItem(item);
			for (int j = 0; j < 5; j++) {
				ItemDetailDAO itemDetail = new ItemDetailDAO();
				itemDetail.setComplete(false);
				itemDetail.setName("detail " + j);
				itemDetail.setId(j);
				mockDataModel.addItemDetail(i, itemDetail);
			}
		}
	}

	@Test
	public void testGetAllItemDetail() {
		int listSize  = mockDataModel.getItemList().size();
		for (int i = 0; i < listSize; i++) {
			ArrayList<ItemDetailDAO> detailList = (ArrayList<ItemDetailDAO>) mockDataModel.getItemDetailList(i);
			assertTrue(detailList.size() == this.numberOfDetails);
		}
	}
	
	@Test
	public void testGetItemDetail() {
		int listSize  = mockDataModel.getItemList().size();
		for (int i = 0; i < listSize; i++)
		{
			ArrayList<ItemDetailDAO> itemDetailList = (ArrayList<ItemDetailDAO>) mockDataModel.getItemDetailList(i);
			for (int j = 0; j < itemDetailList.size(); j++)
			{
				ItemDetailDAO itemDetail = itemDetailList.get(j);
				ItemDetailDAO newItemDetail = mockDataModel.getItemDetail(i, itemDetail.getId());
				assertTrue(itemDetail.getId() == newItemDetail.getId());
				assertTrue(itemDetail.isComplete() == newItemDetail.isComplete());
				assertTrue(itemDetail.getName() == newItemDetail.getName());
			}
		}
	}

	@Test
	public void testAddItemDetail() {
		int listSize  = mockDataModel.getItemList().size();
		for (int i = 0; i < listSize; i++) {
			ItemDetailDAO itemDetail = new ItemDetailDAO();
			itemDetail.setComplete(true);
			itemDetail.setName("detail 6");
			ItemDetailDAO newItemDetail = mockDataModel.addItemDetail(i, itemDetail);
			assertTrue(newItemDetail.isComplete() == itemDetail.isComplete());
			assertTrue(newItemDetail.getName() == itemDetail.getName());
		}
	}

	@Test
	public void testDeleteItemDetail() {
		int listSize  = mockDataModel.getItemList().size();
		for (int i = 0; i < listSize; i++)
		{
			ArrayList<ItemDetailDAO> itemDetailList = (ArrayList<ItemDetailDAO>) mockDataModel.getItemDetailList(i);
			for (int j = 0; j < itemDetailList.size(); j++)
			{
				ItemDetailDAO itemDetail = itemDetailList.get(j);
				mockDataModel.removeItemDetail(i,  itemDetail.getId());
				assertNull(mockDataModel.getItemDetail(i, itemDetail.getId()));
			}
		}
	}

	@Test
	public void testUpdateItemDetail() {
		int listSize  = mockDataModel.getItemList().size();
		for (int i = 0; i < listSize; i++)
		{
			ArrayList<ItemDetailDAO> itemDetailList = (ArrayList<ItemDetailDAO>) mockDataModel.getItemDetailList(i);
			for (int j = 0; j < itemDetailList.size(); j++)
			{
				ItemDetailDAO itemDetail = itemDetailList.get(j);
				itemDetail.setComplete(true);
				itemDetail.setName("detailTest" + j);
				mockDataModel.updateItemDetail(i,  itemDetail.getId(), itemDetail);
				ItemDetailDAO newItemDetail = mockDataModel.getItemDetail(i, itemDetail.getId());
				assertTrue(itemDetail.getId() == newItemDetail.getId());
				assertTrue(itemDetail.isComplete() == newItemDetail.isComplete());
				assertTrue(itemDetail.getName() == newItemDetail.getName());
			}
		}
	}

}
