package com.wk.prototype.RestServices;

import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.wk.prototype.DataModel.MockDataModel;
import com.wk.prototype.ModelDAO.ItemDAO;

public class ItemModelServiceTest {

	private int numberOfItems = 0;
	private MockDataModel mockDataModel;

	/*
	 * 
	 */
	@Before
	public void init() {
		mockDataModel = new MockDataModel();
		numberOfItems = 0;
		for (int i = 0; i < 10; i++) {
			ItemDAO item = new ItemDAO();
			item.setId(i);
			item.setName("item " + i);
			item.setItemDetailList(null);
			mockDataModel.addItem(item);
			numberOfItems++;
		}
	}

	/*
	 * note: although a very simple test, this case did point out an issue in
	 * the Mock data model where the list was inadvertently coded as static
	 */
	@Test
	@Ignore
	public void testGetAllItems() {
		ArrayList<ItemDAO> itemList = (ArrayList<ItemDAO>) mockDataModel.getItemList();
		assertTrue(itemList.size() == numberOfItems);
	}

	/*
	 * 
	 */
	@Test
	@Ignore
	public void testAddItem() {
		int itemNumber = numberOfItems++;
		ItemDAO item = new ItemDAO();
		item.setId(itemNumber);
		item.setName("item " + itemNumber);
		item.setItemDetailList(null);
		mockDataModel.addItem(item);

		ItemDAO itemx = mockDataModel.getItem(itemNumber);
		assertSame(item, itemx);
	}

	/*
	 * 
	 */
	@Test
	@Ignore
	public void testDeleteItem() {
		int initialSize = mockDataModel.getItemList().size();
		int arraySize = initialSize;
		for (int i = 0; i < arraySize; i++) {
			mockDataModel.removeItem(i);
			arraySize--;
			assertTrue(mockDataModel.getItemList().size() == arraySize);
		}
	}

	/*
	 * 
	 */
	@Test
	@Ignore
	public void testUpdateItem() {
		int arraySize = mockDataModel.getItemList().size();
		for (int i = 0; i < arraySize; i++) {
			String newName = "new name " + i;
			ItemDAO item = mockDataModel.getItem(i);
			item.setName(newName);
			mockDataModel.updateItem(i, item);
			ItemDAO newItem = mockDataModel.getItem(i);
			assertTrue(newItem.getName() == newName);
		}
	}

}
